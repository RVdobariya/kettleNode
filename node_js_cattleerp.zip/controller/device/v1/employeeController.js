/**
 * employeeController.js
 * @description : exports action methods for employee.
 */

const Employee = require('../../../model/employee');
const employeeSchemaKey = require('../../../utils/validation/employeeValidation');
const validation = require('../../../utils/validateRequest');
const dbService = require('../../../utils/dbService');
const ObjectId = require('mongodb').ObjectId;
const utils = require('../../../utils/common');
const COW = require('../../../model/COW');
const dairy_product = require('../../../model/dairy_product');
const DairyMetrics = require('../../../model/DairyMetrics');
const default_variable = require('../../../model/default_variable');
const emp_attendance = require('../../../model/emp_attendance');
const emp_joining = require('../../../model/emp_joining');
const emp_leave = require('../../../model/emp_leave');
const employee = require('../../../model/employee');
const item_master = require('../../../model/item_master');
const milk_history = require('../../../model/milk_history');
const milk_usage = require('../../../model/milk_usage');
const milk = require('../../../model/milk');
const sales_item = require('../../../model/sales_items');
const sales_transaction = require('../../../model/sales_transaction');
const shedTransferHistory = require('../../../model/shedTransferHistory');
const stock = require('../../../model/stock');
const user = require('../../../model/user');
const vdr = require('../../../model/vdr');
const report = require('../../../model/report');


/**
 * @description : create document of Employee in mongodb collection.
 * @param {Object} req : request including body for creating document.
 * @param {Object} res : response of created document
 * @return {Object} : created Employee. {status, message, data}
 */
const addEmployee = async (req, res) => {
  try {
    let dataToCreate = { ...req.body || {} };
    let validateRequest = validation.validateParamsWithJoi(
      dataToCreate,
      employeeSchemaKey.schemaKeys);
    if (!validateRequest.isValid) {
      return res.validationError({ message: `Invalid values in parameters, ${validateRequest.message}` });
    }

    let empJoining = {
      "emp_id": dataToCreate.emp_id,
      "join_date": dataToCreate.joining_date,
      "gaushala_id": req.user.gaushala_id,
      "leave_date": "NA",
      "remark": "NA",
      "isActive": true
    };

    const checkEmpId = await dbService.findAll(Employee, { emp_id: dataToCreate.emp_id });

    if (checkEmpId.length != 0) {
      return res.alreadyExist({ data: "Employee Alreday Exist" });
    }

    dataToCreate.gaushala_id = req.user.gaushala_id

    dataToCreate = new Employee(dataToCreate);
    let createdEmployee = await dbService.create(Employee, dataToCreate);

    empJoining = new emp_joining(empJoining);
    await dbService.create(emp_joining, empJoining);

    return res.success({ data: createdEmployee });
  } catch (error) {
    return res.internalServerError({ message: error.message });
  }
};

/**
 * @description : create multiple documents of Employee in mongodb collection.
 * @param {Object} req : request including body for creating documents.
 * @param {Object} res : response of created documents.
 * @return {Object} : created Employees. {status, message, data}
 */
const bulkInsertEmployee = async (req, res) => {
  try {
    if (req.body && (!Array.isArray(req.body.data) || req.body.data.length < 1)) {
      return res.badRequest();
    }
    let dataToCreate = [...req.body.data];
    for (let i = 0; i < dataToCreate.length; i++) {
      dataToCreate[i].gaushala_id = req.user.gaushala_id
    }
    let createdEmployees = await dbService.create(Employee, dataToCreate);
    createdEmployees = { count: createdEmployees ? createdEmployees.length : 0 };
    return res.success({ data: { count: createdEmployees.count || 0 } });
  } catch (error) {
    return res.internalServerError({ message: error.message });
  }
};

/**
 * @description : find all documents of Employee from collection based on query and options.
 * @param {Object} req : request including option and query. {query, options : {page, limit, pagination, populate}, isCountOnly}
 * @param {Object} res : response contains data found from collection.
 * @return {Object} : found Employee(s). {status, message, data}
 */
const findAllEmployee = async (req, res) => {
  try {
    const reqBody = {
      "query": {
      },
      "options": {
        "select": [
          "emp_id",
          "payroll_name",
          "isActive"
        ],
        "collation": "",
        "sort": "",
        "populate": "",
        "projection": "",
        "lean": false,
        "leanWithId": true,
        "offset": 0,
        "page": 1,
        "limit": 10,
        "pagination": false,
        "useEstimatedCount": false,
        "useCustomCountFn": false,
        "forceCountFn": false,
        "read": {},
        "options": {}
      },
      "isCountOnly": false
    };

    // const fieldToAdd = { gaushala_id: '01' }; // Replace with the desired gaushala_id value

    // // // Update all documents in the collection
    // report.updateMany({}, { $set: fieldToAdd }, (updateErr, result) => {
    //   if (updateErr) {
    //   } else {
    //   }
    // });

    let options = reqBody.options;
    let query = reqBody.query;
    query.gaushala_id = req.user.gaushala_id;
    let validateRequest = validation.validateFilterWithJoi(
      req.body,
      employeeSchemaKey.findFilterKeys,
      Employee.schema.obj
    );
    if (!validateRequest.isValid) {
      return res.validationError({ message: `${validateRequest.message}` });
    }
    if (typeof req.body.query === 'object' && req.body.query !== null) {
      query = { ...req.body.query };
    }
    if (req.body.isCountOnly) {
      let totalRecords = await dbService.count(Employee, query);
      return res.success({ data: { totalRecords } });
    }
    if (req.body && typeof req.body.options === 'object' && req.body.options !== null) {
      options = { ...req.body.options };
    }
    let foundEmployees = await dbService.paginate(Employee, query, options);
    if (!foundEmployees || !foundEmployees.data || !foundEmployees.data.length) {
      return res.recordNotFound();
    }
    return res.success({ data: foundEmployees });
  } catch (error) {
    return res.internalServerError({ message: error.message });
  }
};

/**
 * @description : find document of Employee from table by id;
 * @param {Object} req : request including id in request params.
 * @param {Object} res : response contains document retrieved from table.
 * @return {Object} : found Employee. {status, message, data}
 */
const getEmployee = async (req, res) => {
  try {
    let query = {};
    query.gaushala_id = req.user.gaushala_id;
    if (!ObjectId.isValid(req.params.id)) {
      return res.validationError({ message: 'invalid objectId.' });
    }
    query._id = req.params.id;
    let options = {};
    let foundEmployee = await dbService.findOne(Employee, query, options);
    if (!foundEmployee) {
      return res.recordNotFound();
    }
    return res.success({ data: foundEmployee });
  }
  catch (error) {
    return res.internalServerError({ message: error.message });
  }
};

/**
 * @description : returns total number of documents of Employee.
 * @param {Object} req : request including where object to apply filters in req body 
 * @param {Object} res : response that returns total number of documents.
 * @return {Object} : number of documents. {status, message, data}
 */
const getEmployeeCount = async (req, res) => {
  try {
    let where = {};
    where.gaushala_id = req.user.gaushala_id;
    let validateRequest = validation.validateFilterWithJoi(
      req.body,
      employeeSchemaKey.findFilterKeys,
    );
    if (!validateRequest.isValid) {
      return res.validationError({ message: `${validateRequest.message}` });
    }
    if (typeof req.body.where === 'object' && req.body.where !== null) {
      where = { ...req.body.where };
    }
    let countedEmployee = await dbService.count(Employee, where);
    return res.success({ data: { count: countedEmployee } });
  } catch (error) {
    return res.internalServerError({ message: error.message });
  }
};

/**
 * @description : update document of Employee with data by id.
 * @param {Object} req : request including id in request params and data in request body.
 * @param {Object} res : response of updated Employee.
 * @return {Object} : updated Employee. {status, message, data}
 */
const updateEmployee = async (req, res) => {
  try {
    let dataToUpdate = { ...req.body, };
    let validateRequest = validation.validateParamsWithJoi(
      dataToUpdate,
      employeeSchemaKey.updateSchemaKeys
    );
    if (!validateRequest.isValid) {
      return res.validationError({ message: `Invalid values in parameters, ${validateRequest.message}` });
    }
    let query = { _id: req.params.id };
    query.gaushala_id = req.user.gaushala_id;
    let updatedEmployee = await dbService.updateOne(Employee, query, dataToUpdate);
    if (!updatedEmployee) {
      return res.recordNotFound();
    }
    return res.success({ data: updatedEmployee });
  } catch (error) {
    return res.internalServerError({ message: error.message });
  }
};

/**
 * @description : partially update document of Employee with data by id;
 * @param {obj} req : request including id in request params and data in request body.
 * @param {obj} res : response of updated Employee.
 * @return {obj} : updated Employee. {status, message, data}
 */
const partialUpdateEmployee = async (req, res) => {
  try {
    if (!req.params.id) {
      res.badRequest({ message: 'Insufficient request parameters! id is required.' });
    }
    let dataToUpdate = { ...req.body, };
    let validateRequest = validation.validateParamsWithJoi(
      dataToUpdate,
      employeeSchemaKey.updateSchemaKeys
    );
    if (!validateRequest.isValid) {
      return res.validationError({ message: `Invalid values in parameters, ${validateRequest.message}` });
    }
    let query = { _id: req.params.id };
    query.gaushala_id = req.user.gaushala_id;
    let updatedEmployee = await dbService.updateOne(Employee, query, dataToUpdate);
    if (!updatedEmployee) {
      return res.recordNotFound();
    }
    return res.success({ data: updatedEmployee });
  } catch (error) {
    return res.internalServerError({ message: error.message });
  }
};

const updateEmployeeSalary = async (req, res) => {
  try {
    const dataToUpdate = { ...req.body };
    let validateRequest = validation.validateParamsWithJoi(
      dataToUpdate,
      employeeSchemaKey.salaryUpdateSchemaKeys
    );

    if (!validateRequest.isValid) {
      return res.validationError({ message: `Invalid values in parameters, ${validateRequest.message}` });
    }

    const findEmployee = await dbService.findOne(employee, { emp_id: dataToUpdate.emp_id, gaushala_id: req.user.gaushala_id });

    if (!findEmployee) {
      return res.recordNotFound({ message: `Employee not found ${dataToUpdate.emp_id}` });
    }

    // Add the new salary entry to the salary array
    const newSalaryEntry = {
      date: dataToUpdate.date,
      amountDecided: dataToUpdate.amountDecided
    };

    findEmployee.salary.push(newSalaryEntry);

    // Update the employee document in the database
    const updatedEmployee = await dbService.updateOne(employee,
      { emp_id: dataToUpdate.emp_id, gaushala_id: req.user.gaushala_id },
      { $set: { salary: findEmployee.salary } }
    );

    return res.success({ message: 'Salary updated successfully', data: updatedEmployee });

  } catch (error) {
    return res.internalServerError({ message: error.message });
  }
};

const updateEmpDod = async (req, res) => {
  try {
    const errorTags = [];
    const successTags = [];

    const allEmployees = await Employee.find();

    allEmployees.forEach(async function (doc) {
      var originalDate = doc.join_date;
      console.log(originalDate)
      var parts = originalDate.split(/[/\-]/);

      if (parts.length >= 3) {
        var year = parts[2].length === 2 ? '20' + parts[2] : parts[2];
        var month = parts[1].padStart(2, '0');
        var day = parts[0].padStart(2, '0');

        var newDate = year + '-' + month + '-' + day;

        await Employee.updateOne(
          { _id: doc._id },
          { $set: { join_date: newDate } }
        );

        console.log({ emp_id: doc.emp_id, originalDate, newDate })

        successTags.push({ emp_id: doc.emp_id, originalDate, newDate })
      }
    });


    return res.success({ data: { errorTags, successTags } })

  } catch (error) {
    return res.internalServerError({ message: error.message });
  }
};

module.exports = {
  updateEmpDod,
  updateEmployeeSalary,
  addEmployee,
  bulkInsertEmployee,
  findAllEmployee,
  getEmployee,
  getEmployeeCount,
  updateEmployee,
  partialUpdateEmployee
};