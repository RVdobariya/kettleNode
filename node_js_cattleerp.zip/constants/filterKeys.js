/**
 * filterKeys.js
 */

module.exports = {
  FILTER_KEYS: {
    _ID: '_id',
    ID: 'id' 
  } 
};
